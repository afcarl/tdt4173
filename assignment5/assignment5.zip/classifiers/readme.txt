This is the folder where classifiers are stored
